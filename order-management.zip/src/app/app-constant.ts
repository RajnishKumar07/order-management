export const APP_CONSTANT = {
  currency: 'INR',
  noImageUrl: '/assets/No_Image_Available.jpg',
  noDataImageUrl: '/assets/no-data.jpeg',
};
