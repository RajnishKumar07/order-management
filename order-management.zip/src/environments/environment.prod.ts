// environment.prod.ts
export const environment = {
  production: true,
  apiUrl: 'https://e-commerce-api-yyqb.onrender.com/api/v1',
};
