export const environment = {
  production: false,

  apiUrl: 'https://dummy.restapiexample.com/api/v1/',
};
